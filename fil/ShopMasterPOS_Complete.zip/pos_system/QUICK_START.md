# QUICK START GUIDE
## Get Your ShopMaster POS Running in 10 Minutes!

---

## ⚡ SUPER FAST SETUP

### STEP 1: Install Python (5 minutes)

1. Go to: **https://www.python.org/downloads/**
2. Download Python (latest version)
3. Run the installer
4. ✅ **CRITICAL:** Check "Add Python to PATH"
5. Click "Install Now"
6. Wait... Done!

### STEP 2: Install Packages (2 minutes)

1. Press **Windows Key + R**
2. Type: **cmd**
3. Press **Enter**
4. Copy and paste this ONE command:

```
pip install pillow reportlab openpyxl tkcalendar
```

5. Press **Enter** and wait... Done!

### STEP 3: Setup Database (1 minute)

1. Open the folder where you saved the POS files
2. In Command Prompt (cmd), type:

```
cd [PATH_TO_YOUR_POS_FOLDER]
```

Example: `cd C:\ShopMasterPOS`

3. Then type:

```
python database_setup.py
```

4. You'll see success messages... Done!

### STEP 4: Start System (1 minute)

1. In the same Command Prompt, type:

```
python main_pos.py
```

2. Login screen appears!
3. Login with:
   - **Username:** admin
   - **Password:** admin123

### STEP 5: Start Selling! (1 minute)

1. Click **Admin → Shop Settings**
2. Enter your shop name
3. Click **Inventory → Products**
4. Add a few products
5. **Start selling!**

---

## 🎯 YOUR FIRST SALE

1. Press **F1** (New Sale)
2. Scan barcode OR press **F3** to search product
3. Add products to cart
4. Click **COMPLETE SALE** (F5)
5. Enter amount paid
6. Print receipt
7. **Done!**

---

## 📋 WHAT'S IN THE PACKAGE

### FILES YOU RECEIVED:

1. **main_pos.py** - The main application (run this!)
2. **database_setup.py** - Database creator (run once)
3. **README.md** - Complete documentation
4. **docs/** folder:
   - INSTALLATION_GUIDE.md - Detailed setup instructions
   - USER_MANUAL.md - How to use everything
   - SYSTEM_OVERVIEW.md - All features explained

### FILES CREATED AUTOMATICALLY:

- **pos_database.db** - Your data (BACKUP THIS!)
- **backup/** folder - Automatic backups

---

## ⚙️ IMPORTANT FIRST STEPS

### IMMEDIATELY AFTER FIRST LOGIN:

1. ✅ **Change admin password**
   - Click: File → Change Password
   - Choose a STRONG password

2. ✅ **Setup your shop**
   - Click: Admin → Shop Settings
   - Enter all your details

3. ✅ **Add products**
   - Click: Inventory → Products
   - Add your inventory

4. ✅ **Create users**
   - Click: Admin → User Management
   - Add staff accounts

5. ✅ **Configure backup**
   - Click: Admin → Backup Database
   - Set automatic daily backup

---

## 🎓 LEARN MORE

### READ THESE IN ORDER:

1. **INSTALLATION_GUIDE.md** - Detailed setup (if you have issues)
2. **USER_MANUAL.md** - How to do everything
3. **SYSTEM_OVERVIEW.md** - All features explained

### KEYBOARD SHORTCUTS:

- **F1** - New Sale
- **F2** - Focus search box
- **F3** - Search product
- **F4** - Clear cart
- **F5** - Complete sale

---

## ❓ HAVING PROBLEMS?

### "Python is not recognized"
**Fix:** Reinstall Python and CHECK "Add Python to PATH"

### "pip is not recognized"  
**Fix:** Same as above - Python PATH issue

### "Module not found"
**Fix:** Run: `pip install [module-name]`

### System won't start
**Fix:** Run from Command Prompt to see error message

### Need more help?
**Read:** INSTALLATION_GUIDE.md (detailed troubleshooting)

---

## 💡 PRO TIPS

1. **Use keyboard shortcuts** - Much faster!
2. **Backup daily** - Never lose data
3. **Train staff properly** - Read User Manual together
4. **Keep documentation handy** - You'll need it
5. **Test everything first** - Use sample data before going live

---

## 📞 NEXT STEPS

1. ✅ System running? **Great!**
2. Read USER_MANUAL.md for daily operations
3. Practice with test data
4. Train your staff
5. Go live!

---

## 🎉 YOU'RE READY!

**System installed? ✅**  
**Shop configured? ✅**  
**Products added? ✅**  
**Staff trained? ✅**

**START SELLING!** 🚀

---

**Having trouble?** Check INSTALLATION_GUIDE.md for detailed help.

**Need training?** Read USER_MANUAL.md completely.

**Want to know everything?** Read SYSTEM_OVERVIEW.md.

---

## 🔐 REMEMBER

- **Default username:** admin
- **Default password:** admin123
- **⚠️ CHANGE THIS IMMEDIATELY!**

---

**Good luck with your business!** 💼

© 2026 ShopMaster POS
