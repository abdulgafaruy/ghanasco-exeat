"""
SHOPMASTER POS - MAIN APPLICATION
Complete Point of Sale System with GUI
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import sqlite3
from datetime import datetime
import os

class POSMainWindow:
    def __init__(self, root, user_id, username, role):
        self.root = root
        self.user_id = user_id
        self.username = username
        self.role = role
        
        # Database connection
        self.db_path = "pos_database.db"
        
        # Configure main window
        self.root.title(f"ShopMaster POS - Logged in as: {username} ({role})")
        self.root.state('zoomed')  # Maximize window
        
        # Set theme colors
        self.primary_color = "#2c3e50"
        self.secondary_color = "#3498db"
        self.success_color = "#27ae60"
        self.danger_color = "#e74c3c"
        self.light_bg = "#ecf0f1"
        
        # Current sale data
        self.current_sale_items = []
        self.current_customer_id = None
        
        self.create_menu_bar()
        self.create_main_interface()
        self.load_shop_info()
        
    def create_menu_bar(self):
        """Create top menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Sale (F1)", command=self.new_sale)
        file_menu.add_separator()
        file_menu.add_command(label="Logout", command=self.logout)
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Sales Menu
        sales_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Sales", menu=sales_menu)
        sales_menu.add_command(label="Process Sale (F2)", command=self.focus_barcode)
        sales_menu.add_command(label="View Sales History", command=self.view_sales_history)
        sales_menu.add_command(label="Sales Return", command=self.sales_return)
        
        # Inventory Menu
        inventory_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Inventory", menu=inventory_menu)
        inventory_menu.add_command(label="Products", command=self.manage_products)
        inventory_menu.add_command(label="Categories", command=self.manage_categories)
        inventory_menu.add_command(label="Stock Adjustment", command=self.stock_adjustment)
        inventory_menu.add_command(label="Low Stock Alert", command=self.low_stock_alert)
        
        # Customers Menu
        customers_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Customers", menu=customers_menu)
        customers_menu.add_command(label="Manage Customers", command=self.manage_customers)
        customers_menu.add_command(label="Customer Statement", command=self.customer_statement)
        
        # Reports Menu
        reports_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Reports", menu=reports_menu)
        reports_menu.add_command(label="Daily Sales Report", command=self.daily_sales_report)
        reports_menu.add_command(label="Monthly Sales Report", command=self.monthly_sales_report)
        reports_menu.add_command(label="Profit Analysis", command=self.profit_analysis)
        reports_menu.add_command(label="Product Movement", command=self.product_movement)
        reports_menu.add_command(label="Stock Valuation", command=self.stock_valuation)
        
        # Admin Menu (Only for Admin and Manager)
        if self.role in ['Admin', 'Manager']:
            admin_menu = tk.Menu(menubar, tearoff=0)
            menubar.add_cascade(label="Admin", menu=admin_menu)
            admin_menu.add_command(label="Shop Settings", command=self.shop_settings)
            admin_menu.add_command(label="Suppliers", command=self.manage_suppliers)
            admin_menu.add_command(label="Expenses", command=self.manage_expenses)
            
            if self.role == 'Admin':
                admin_menu.add_separator()
                admin_menu.add_command(label="User Management", command=self.user_management)
                admin_menu.add_command(label="Backup Database", command=self.backup_database)
                admin_menu.add_command(label="Activity Log", command=self.activity_log)
        
        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="User Guide", command=self.show_user_guide)
        help_menu.add_command(label="Keyboard Shortcuts", command=self.show_shortcuts)
        help_menu.add_command(label="About", command=self.show_about)
    
    def create_main_interface(self):
        """Create main POS interface"""
        
        # Main container
        main_frame = tk.Frame(self.root, bg=self.light_bg)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # ===== LEFT PANEL - Product Entry =====
        left_panel = tk.Frame(main_frame, bg="white", relief=tk.RIDGE, bd=2)
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Title
        title_label = tk.Label(left_panel, text="SALES TERMINAL", 
                               font=("Arial", 16, "bold"), bg=self.primary_color, 
                               fg="white", pady=10)
        title_label.pack(fill=tk.X)
        
        # Barcode Entry Frame
        entry_frame = tk.Frame(left_panel, bg="white", pady=10)
        entry_frame.pack(fill=tk.X, padx=10)
        
        tk.Label(entry_frame, text="Scan Barcode / Search Product:", 
                font=("Arial", 11, "bold"), bg="white").pack(anchor="w")
        
        self.barcode_entry = tk.Entry(entry_frame, font=("Arial", 14), 
                                      relief=tk.SOLID, bd=2)
        self.barcode_entry.pack(fill=tk.X, pady=5)
        self.barcode_entry.bind('<Return>', self.add_product_by_barcode)
        self.barcode_entry.focus()
        
        # Quick buttons
        button_frame = tk.Frame(entry_frame, bg="white")
        button_frame.pack(fill=tk.X, pady=5)
        
        tk.Button(button_frame, text="Search Product (F3)", 
                 bg=self.secondary_color, fg="white", font=("Arial", 10, "bold"),
                 command=self.search_product_window, relief=tk.FLAT, 
                 cursor="hand2").pack(side=tk.LEFT, padx=2)
        
        tk.Button(button_frame, text="Clear (F4)", 
                 bg=self.danger_color, fg="white", font=("Arial", 10, "bold"),
                 command=self.new_sale, relief=tk.FLAT, 
                 cursor="hand2").pack(side=tk.LEFT, padx=2)
        
        # Sale Items Table
        tk.Label(left_panel, text="ITEMS IN CART", font=("Arial", 12, "bold"), 
                bg="white").pack(pady=(10, 5))
        
        # Create Treeview for sale items
        columns = ('Product', 'Qty', 'Price', 'Discount', 'Total')
        self.sale_tree = ttk.Treeview(left_panel, columns=columns, 
                                      show='headings', height=15)
        
        # Configure columns
        self.sale_tree.heading('Product', text='Product Name')
        self.sale_tree.heading('Qty', text='Qty')
        self.sale_tree.heading('Price', text='Unit Price')
        self.sale_tree.heading('Discount', text='Disc.')
        self.sale_tree.heading('Total', text='Total')
        
        self.sale_tree.column('Product', width=300)
        self.sale_tree.column('Qty', width=80, anchor='center')
        self.sale_tree.column('Price', width=100, anchor='e')
        self.sale_tree.column('Discount', width=80, anchor='e')
        self.sale_tree.column('Total', width=120, anchor='e')
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(left_panel, orient=tk.VERTICAL, 
                                 command=self.sale_tree.yview)
        self.sale_tree.configure(yscroll=scrollbar.set)
        
        self.sale_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 0))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 10))
        
        # Right-click menu for sale items
        self.item_menu = tk.Menu(self.sale_tree, tearoff=0)
        self.item_menu.add_command(label="Remove Item", command=self.remove_item)
        self.item_menu.add_command(label="Change Quantity", command=self.change_quantity)
        self.item_menu.add_command(label="Apply Discount", command=self.apply_discount)
        self.sale_tree.bind("<Button-3>", self.show_item_menu)
        
        # ===== RIGHT PANEL - Summary and Payment =====
        right_panel = tk.Frame(main_frame, bg="white", relief=tk.RIDGE, bd=2, width=400)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(5, 0))
        right_panel.pack_propagate(False)
        
        # Shop Info
        info_frame = tk.Frame(right_panel, bg=self.primary_color, pady=10)
        info_frame.pack(fill=tk.X)
        
        self.shop_name_label = tk.Label(info_frame, text="SHOP NAME", 
                                        font=("Arial", 14, "bold"), 
                                        bg=self.primary_color, fg="white")
        self.shop_name_label.pack()
        
        self.date_label = tk.Label(info_frame, 
                                   text=datetime.now().strftime("%d %B %Y - %I:%M %p"),
                                   font=("Arial", 10), bg=self.primary_color, fg="white")
        self.date_label.pack()
        
        # Update time every second
        self.update_time()
        
        # Summary Frame
        summary_frame = tk.Frame(right_panel, bg="white", pady=20)
        summary_frame.pack(fill=tk.BOTH, expand=True, padx=20)
        
        # Customer selection
        tk.Label(summary_frame, text="Customer:", font=("Arial", 10, "bold"),
                bg="white").pack(anchor="w")
        
        customer_frame = tk.Frame(summary_frame, bg="white")
        customer_frame.pack(fill=tk.X, pady=5)
        
        self.customer_var = tk.StringVar(value="Walk-in Customer")
        self.customer_combo = ttk.Combobox(customer_frame, textvariable=self.customer_var,
                                          font=("Arial", 10), state="readonly")
        self.customer_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.load_customers()
        
        tk.Button(customer_frame, text="+", font=("Arial", 10, "bold"),
                 bg=self.success_color, fg="white", width=3,
                 command=self.add_customer_quick).pack(side=tk.LEFT, padx=(5, 0))
        
        # Separator
        ttk.Separator(summary_frame, orient='horizontal').pack(fill=tk.X, pady=20)
        
        # Summary Labels
        summary_data = tk.Frame(summary_frame, bg="white")
        summary_data.pack(fill=tk.X)
        
        # Items count
        tk.Label(summary_data, text="Items:", font=("Arial", 11),
                bg="white").grid(row=0, column=0, sticky="w", pady=5)
        self.items_count_label = tk.Label(summary_data, text="0", 
                                         font=("Arial", 11, "bold"),
                                         bg="white", fg=self.secondary_color)
        self.items_count_label.grid(row=0, column=1, sticky="e", pady=5)
        
        # Subtotal
        tk.Label(summary_data, text="Subtotal:", font=("Arial", 11),
                bg="white").grid(row=1, column=0, sticky="w", pady=5)
        self.subtotal_label = tk.Label(summary_data, text="GHS 0.00", 
                                       font=("Arial", 11),
                                       bg="white")
        self.subtotal_label.grid(row=1, column=1, sticky="e", pady=5)
        
        # Discount
        tk.Label(summary_data, text="Discount:", font=("Arial", 11),
                bg="white").grid(row=2, column=0, sticky="w", pady=5)
        self.discount_label = tk.Label(summary_data, text="GHS 0.00", 
                                       font=("Arial", 11),
                                       bg="white", fg=self.danger_color)
        self.discount_label.grid(row=2, column=1, sticky="e", pady=5)
        
        # Tax
        tk.Label(summary_data, text="Tax:", font=("Arial", 11),
                bg="white").grid(row=3, column=0, sticky="w", pady=5)
        self.tax_label = tk.Label(summary_data, text="GHS 0.00", 
                                 font=("Arial", 11),
                                 bg="white")
        self.tax_label.grid(row=3, column=1, sticky="e", pady=5)
        
        summary_data.columnconfigure(1, weight=1)
        
        # Total (Prominent)
        ttk.Separator(summary_frame, orient='horizontal').pack(fill=tk.X, pady=10)
        
        total_frame = tk.Frame(summary_frame, bg=self.success_color, relief=tk.RAISED, bd=3)
        total_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(total_frame, text="TOTAL:", font=("Arial", 14, "bold"),
                bg=self.success_color, fg="white").pack(side=tk.LEFT, padx=10, pady=10)
        
        self.total_label = tk.Label(total_frame, text="GHS 0.00", 
                                    font=("Arial", 20, "bold"),
                                    bg=self.success_color, fg="white")
        self.total_label.pack(side=tk.RIGHT, padx=10, pady=10)
        
        # Payment Method
        tk.Label(summary_frame, text="Payment Method:", font=("Arial", 10, "bold"),
                bg="white").pack(anchor="w", pady=(10, 5))
        
        self.payment_var = tk.StringVar(value="Cash")
        payment_methods = ["Cash", "Mobile Money", "Card", "Credit", "Bank Transfer"]
        
        payment_frame = tk.Frame(summary_frame, bg="white")
        payment_frame.pack(fill=tk.X)
        
        for method in payment_methods:
            tk.Radiobutton(payment_frame, text=method, variable=self.payment_var,
                          value=method, font=("Arial", 9), bg="white",
                          cursor="hand2").pack(anchor="w")
        
        # Action Buttons
        button_container = tk.Frame(right_panel, bg="white", pady=15)
        button_container.pack(fill=tk.X, padx=20)
        
        tk.Button(button_container, text="COMPLETE SALE (F5)", 
                 font=("Arial", 12, "bold"), bg=self.success_color, fg="white",
                 command=self.complete_sale, relief=tk.FLAT, cursor="hand2",
                 pady=15).pack(fill=tk.X, pady=5)
        
        tk.Button(button_container, text="Hold Sale", 
                 font=("Arial", 10), bg=self.secondary_color, fg="white",
                 command=self.hold_sale, relief=tk.FLAT, cursor="hand2",
                 pady=10).pack(fill=tk.X, pady=5)
        
        # Keyboard shortcuts
        self.root.bind('<F1>', lambda e: self.new_sale())
        self.root.bind('<F2>', lambda e: self.focus_barcode())
        self.root.bind('<F3>', lambda e: self.search_product_window())
        self.root.bind('<F4>', lambda e: self.new_sale())
        self.root.bind('<F5>', lambda e: self.complete_sale())
    
    def update_time(self):
        """Update time display every second"""
        current_time = datetime.now().strftime("%d %B %Y - %I:%M:%S %p")
        self.date_label.config(text=current_time)
        self.root.after(1000, self.update_time)
    
    def load_shop_info(self):
        """Load shop information from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT shop_name FROM shop_settings LIMIT 1")
            result = cursor.fetchone()
            if result:
                self.shop_name_label.config(text=result[0])
            conn.close()
        except Exception as e:
            print(f"Error loading shop info: {e}")
    
    def load_customers(self):
        """Load customers into combobox"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                SELECT customer_id, customer_name 
                FROM customers 
                WHERE is_active = 1 
                ORDER BY customer_name
            """)
            customers = cursor.fetchall()
            conn.close()
            
            customer_list = [f"{name}" for cid, name in customers]
            self.customer_combo['values'] = customer_list
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load customers: {e}")
    
    def focus_barcode(self):
        """Focus on barcode entry field"""
        self.barcode_entry.focus()
        self.barcode_entry.select_range(0, tk.END)
    
    def add_product_by_barcode(self, event=None):
        """Add product to sale by barcode or name search"""
        search_term = self.barcode_entry.get().strip()
        
        if not search_term:
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Search by barcode or product name
            cursor.execute("""
                SELECT product_id, product_name, selling_price, quantity_in_stock, barcode
                FROM products
                WHERE (barcode = ? OR LOWER(product_name) LIKE ?) 
                AND is_active = 1
                LIMIT 1
            """, (search_term, f"%{search_term.lower()}%"))
            
            product = cursor.fetchone()
            conn.close()
            
            if product:
                product_id, name, price, stock, barcode = product
                
                if stock <= 0:
                    messagebox.showwarning("Out of Stock", 
                                         f"{name} is out of stock!")
                    self.barcode_entry.delete(0, tk.END)
                    return
                
                # Add to cart
                self.add_to_cart(product_id, name, price, 1, 0)
                self.barcode_entry.delete(0, tk.END)
                
            else:
                messagebox.showwarning("Not Found", 
                                     "Product not found. Use F3 to search.")
                self.barcode_entry.delete(0, tk.END)
                
        except Exception as e:
            messagebox.showerror("Error", f"Database error: {e}")
    
    def add_to_cart(self, product_id, name, price, quantity, discount):
        """Add item to shopping cart"""
        
        # Check if item already in cart
        for i, item in enumerate(self.current_sale_items):
            if item['product_id'] == product_id:
                # Update quantity
                self.current_sale_items[i]['quantity'] += quantity
                self.refresh_sale_display()
                return
        
        # Add new item
        total = (price * quantity) - discount
        self.current_sale_items.append({
            'product_id': product_id,
            'name': name,
            'price': price,
            'quantity': quantity,
            'discount': discount,
            'total': total
        })
        
        self.refresh_sale_display()
    
    def refresh_sale_display(self):
        """Refresh the sale items display and totals"""
        
        # Clear treeview
        for item in self.sale_tree.get_children():
            self.sale_tree.delete(item)
        
        # Calculate totals
        subtotal = 0
        total_discount = 0
        
        # Display items
        for item in self.current_sale_items:
            self.sale_tree.insert('', 'end', values=(
                item['name'],
                item['quantity'],
                f"GHS {item['price']:.2f}",
                f"GHS {item['discount']:.2f}",
                f"GHS {item['total']:.2f}"
            ))
            subtotal += (item['price'] * item['quantity'])
            total_discount += item['discount']
        
        # Calculate tax (get from settings)
        tax_rate = 0  # Will be loaded from settings
        tax_amount = (subtotal - total_discount) * (tax_rate / 100)
        
        # Calculate total
        total = subtotal - total_discount + tax_amount
        
        # Update labels
        self.items_count_label.config(text=str(len(self.current_sale_items)))
        self.subtotal_label.config(text=f"GHS {subtotal:.2f}")
        self.discount_label.config(text=f"GHS {total_discount:.2f}")
        self.tax_label.config(text=f"GHS {tax_amount:.2f}")
        self.total_label.config(text=f"GHS {total:.2f}")
    
    def show_item_menu(self, event):
        """Show right-click menu on sale items"""
        selection = self.sale_tree.selection()
        if selection:
            self.item_menu.post(event.x_root, event.y_root)
    
    def remove_item(self):
        """Remove selected item from cart"""
        selection = self.sale_tree.selection()
        if selection:
            index = self.sale_tree.index(selection[0])
            del self.current_sale_items[index]
            self.refresh_sale_display()
    
    def change_quantity(self):
        """Change quantity of selected item"""
        selection = self.sale_tree.selection()
        if selection:
            index = self.sale_tree.index(selection[0])
            item = self.current_sale_items[index]
            
            # Quantity dialog
            dialog = tk.Toplevel(self.root)
            dialog.title("Change Quantity")
            dialog.geometry("300x150")
            dialog.transient(self.root)
            dialog.grab_set()
            
            tk.Label(dialog, text=f"Product: {item['name']}", 
                    font=("Arial", 10, "bold")).pack(pady=10)
            
            tk.Label(dialog, text="New Quantity:").pack()
            qty_entry = tk.Entry(dialog, font=("Arial", 12), justify='center')
            qty_entry.pack(pady=5)
            qty_entry.insert(0, str(item['quantity']))
            qty_entry.select_range(0, tk.END)
            qty_entry.focus()
            
            def update_qty():
                try:
                    new_qty = int(qty_entry.get())
                    if new_qty > 0:
                        self.current_sale_items[index]['quantity'] = new_qty
                        self.current_sale_items[index]['total'] = (
                            item['price'] * new_qty - item['discount']
                        )
                        self.refresh_sale_display()
                        dialog.destroy()
                    else:
                        messagebox.showwarning("Invalid", "Quantity must be positive")
                except ValueError:
                    messagebox.showerror("Error", "Invalid quantity")
            
            tk.Button(dialog, text="Update", command=update_qty,
                     bg=self.success_color, fg="white").pack(pady=10)
            
            qty_entry.bind('<Return>', lambda e: update_qty())
    
    def apply_discount(self):
        """Apply discount to selected item"""
        selection = self.sale_tree.selection()
        if selection:
            index = self.sale_tree.index(selection[0])
            item = self.current_sale_items[index]
            
            # Discount dialog
            dialog = tk.Toplevel(self.root)
            dialog.title("Apply Discount")
            dialog.geometry("300x200")
            dialog.transient(self.root)
            dialog.grab_set()
            
            tk.Label(dialog, text=f"Product: {item['name']}", 
                    font=("Arial", 10, "bold")).pack(pady=10)
            
            tk.Label(dialog, text=f"Price: GHS {item['price']:.2f}").pack()
            
            discount_type = tk.StringVar(value="fixed")
            tk.Radiobutton(dialog, text="Fixed Amount (GHS)", 
                          variable=discount_type, value="fixed").pack()
            tk.Radiobutton(dialog, text="Percentage (%)", 
                          variable=discount_type, value="percent").pack()
            
            discount_entry = tk.Entry(dialog, font=("Arial", 12), justify='center')
            discount_entry.pack(pady=5)
            discount_entry.focus()
            
            def apply():
                try:
                    discount_value = float(discount_entry.get())
                    
                    if discount_type.get() == "fixed":
                        discount_amount = discount_value
                    else:
                        discount_amount = (item['price'] * item['quantity']) * (discount_value / 100)
                    
                    self.current_sale_items[index]['discount'] = discount_amount
                    self.current_sale_items[index]['total'] = (
                        item['price'] * item['quantity'] - discount_amount
                    )
                    self.refresh_sale_display()
                    dialog.destroy()
                    
                except ValueError:
                    messagebox.showerror("Error", "Invalid discount value")
            
            tk.Button(dialog, text="Apply", command=apply,
                     bg=self.success_color, fg="white").pack(pady=10)
    
    def complete_sale(self):
        """Complete the sale transaction"""
        
        if not self.current_sale_items:
            messagebox.showwarning("Empty Cart", "Add items to cart first!")
            return
        
        # Calculate totals
        subtotal = sum(item['price'] * item['quantity'] for item in self.current_sale_items)
        total_discount = sum(item['discount'] for item in self.current_sale_items)
        tax_amount = 0  # Calculate based on settings
        total_amount = subtotal - total_discount + tax_amount
        
        # Payment dialog
        self.show_payment_dialog(total_amount, subtotal, total_discount, tax_amount)
    
    def show_payment_dialog(self, total_amount, subtotal, total_discount, tax_amount):
        """Show payment dialog for completing sale"""
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Complete Payment")
        dialog.geometry("400x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Display total
        tk.Label(dialog, text="AMOUNT TO PAY", font=("Arial", 12, "bold")).pack(pady=10)
        tk.Label(dialog, text=f"GHS {total_amount:.2f}", 
                font=("Arial", 24, "bold"), fg=self.success_color).pack()
        
        ttk.Separator(dialog, orient='horizontal').pack(fill=tk.X, pady=15)
        
        # Payment method
        tk.Label(dialog, text="Payment Method:", font=("Arial", 10, "bold")).pack()
        payment_method = tk.StringVar(value=self.payment_var.get())
        
        for method in ["Cash", "Mobile Money", "Card", "Credit", "Bank Transfer"]:
            tk.Radiobutton(dialog, text=method, variable=payment_method,
                          value=method, font=("Arial", 10)).pack()
        
        # Amount paid
        tk.Label(dialog, text="Amount Paid:", font=("Arial", 10, "bold")).pack(pady=(10, 5))
        amount_paid_entry = tk.Entry(dialog, font=("Arial", 14), justify='center')
        amount_paid_entry.pack()
        amount_paid_entry.insert(0, f"{total_amount:.2f}")
        amount_paid_entry.select_range(0, tk.END)
        amount_paid_entry.focus()
        
        # Change label
        change_label = tk.Label(dialog, text="Change: GHS 0.00", 
                               font=("Arial", 12, "bold"), fg=self.secondary_color)
        change_label.pack(pady=10)
        
        def calculate_change(event=None):
            try:
                paid = float(amount_paid_entry.get())
                change = paid - total_amount
                change_label.config(text=f"Change: GHS {change:.2f}")
            except:
                change_label.config(text="Change: GHS 0.00")
        
        amount_paid_entry.bind('<KeyRelease>', calculate_change)
        
        def process_payment():
            try:
                amount_paid = float(amount_paid_entry.get())
                
                if amount_paid < total_amount and payment_method.get() != "Credit":
                    messagebox.showwarning("Insufficient Payment", 
                                         "Amount paid is less than total!")
                    return
                
                change_given = max(0, amount_paid - total_amount)
                
                # Save to database
                self.save_sale_to_database(
                    subtotal, total_discount, tax_amount, total_amount,
                    payment_method.get(), amount_paid, change_given
                )
                
                dialog.destroy()
                messagebox.showinfo("Success", "Sale completed successfully!")
                
                # Print receipt (optional)
                print_receipt = messagebox.askyesno("Print Receipt", 
                                                   "Do you want to print receipt?")
                if print_receipt:
                    self.print_receipt()
                
                self.new_sale()
                
            except ValueError:
                messagebox.showerror("Error", "Invalid amount entered!")
        
        tk.Button(dialog, text="COMPLETE PAYMENT", font=("Arial", 12, "bold"),
                 bg=self.success_color, fg="white", command=process_payment,
                 pady=10).pack(fill=tk.X, padx=20, pady=20)
        
        amount_paid_entry.bind('<Return>', lambda e: process_payment())
    
    def save_sale_to_database(self, subtotal, discount, tax, total, 
                             payment_method, amount_paid, change_given):
        """Save completed sale to database"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Generate receipt number
            receipt_number = f"R{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            # Get customer ID
            customer_name = self.customer_var.get()
            cursor.execute("SELECT customer_id FROM customers WHERE customer_name = ?",
                          (customer_name,))
            customer_result = cursor.fetchone()
            customer_id = customer_result[0] if customer_result else 1
            
            # Insert sale record
            cursor.execute("""
                INSERT INTO sales (receipt_number, customer_id, user_id, subtotal, 
                                 discount_amount, tax_amount, total_amount, 
                                 payment_method, amount_paid, change_given, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Completed')
            """, (receipt_number, customer_id, self.user_id, subtotal, discount, 
                 tax, total, payment_method, amount_paid, change_given))
            
            sale_id = cursor.lastrowid
            
            # Insert sale items and update stock
            for item in self.current_sale_items:
                cursor.execute("""
                    INSERT INTO sales_items (sale_id, product_id, quantity, 
                                           unit_price, discount, total_price)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (sale_id, item['product_id'], item['quantity'], 
                     item['price'], item['discount'], item['total']))
                
                # Update product stock
                cursor.execute("""
                    UPDATE products 
                    SET quantity_in_stock = quantity_in_stock - ? 
                    WHERE product_id = ?
                """, (item['quantity'], item['product_id']))
            
            # Log activity
            cursor.execute("""
                INSERT INTO activity_log (user_id, activity_type, activity_description)
                VALUES (?, 'Sale', ?)
            """, (self.user_id, f"Completed sale {receipt_number} - Total: GHS {total:.2f}"))
            
            conn.commit()
            conn.close()
            
            self.last_receipt_number = receipt_number
            
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to save sale: {e}")
    
    def print_receipt(self):
        """Generate and display receipt"""
        # This would normally print to a thermal printer
        # For now, we'll show in a window
        
        receipt_window = tk.Toplevel(self.root)
        receipt_window.title("Receipt")
        receipt_window.geometry("400x600")
        
        receipt_text = scrolledtext.ScrolledText(receipt_window, 
                                                font=("Courier", 10))
        receipt_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Build receipt text
        receipt = "=" * 40 + "\n"
        receipt += "        SHOPMASTER POS\n"
        receipt += "=" * 40 + "\n\n"
        receipt += f"Receipt #: {self.last_receipt_number}\n"
        receipt += f"Date: {datetime.now().strftime('%d/%m/%Y %I:%M %p')}\n"
        receipt += f"Cashier: {self.username}\n"
        receipt += "-" * 40 + "\n\n"
        
        for item in self.current_sale_items:
            receipt += f"{item['name']}\n"
            receipt += f"  {item['quantity']} x GHS {item['price']:.2f} = GHS {item['total']:.2f}\n"
        
        receipt += "\n" + "-" * 40 + "\n"
        receipt += f"Total: GHS {sum(item['total'] for item in self.current_sale_items):.2f}\n"
        receipt += "=" * 40 + "\n"
        receipt += "\n   Thank you for your business!\n"
        receipt += "=" * 40
        
        receipt_text.insert('1.0', receipt)
        receipt_text.config(state='disabled')
    
    def new_sale(self):
        """Start a new sale (clear current sale)"""
        if self.current_sale_items:
            if not messagebox.askyesno("Confirm", "Clear current sale?"):
                return
        
        self.current_sale_items = []
        self.refresh_sale_display()
        self.customer_var.set("Walk-in Customer")
        self.payment_var.set("Cash")
        self.barcode_entry.delete(0, tk.END)
        self.focus_barcode()
    
    def hold_sale(self):
        """Hold current sale for later"""
        if self.current_sale_items:
            messagebox.showinfo("Hold Sale", 
                              "Hold sale feature - Save for later retrieval")
        else:
            messagebox.showwarning("Empty Cart", "No items to hold!")
    
    # Placeholder methods for menu items (to be implemented)
    def search_product_window(self):
        messagebox.showinfo("Search", "Product search window - To be implemented")
    
    def view_sales_history(self):
        messagebox.showinfo("Sales History", "Sales history view - To be implemented")
    
    def sales_return(self):
        messagebox.showinfo("Sales Return", "Sales return function - To be implemented")
    
    def manage_products(self):
        messagebox.showinfo("Products", "Product management - To be implemented")
    
    def manage_categories(self):
        messagebox.showinfo("Categories", "Category management - To be implemented")
    
    def stock_adjustment(self):
        messagebox.showinfo("Stock Adjustment", "Stock adjustment - To be implemented")
    
    def low_stock_alert(self):
        messagebox.showinfo("Low Stock", "Low stock alert - To be implemented")
    
    def manage_customers(self):
        messagebox.showinfo("Customers", "Customer management - To be implemented")
    
    def customer_statement(self):
        messagebox.showinfo("Statement", "Customer statement - To be implemented")
    
    def daily_sales_report(self):
        messagebox.showinfo("Report", "Daily sales report - To be implemented")
    
    def monthly_sales_report(self):
        messagebox.showinfo("Report", "Monthly sales report - To be implemented")
    
    def profit_analysis(self):
        messagebox.showinfo("Report", "Profit analysis - To be implemented")
    
    def product_movement(self):
        messagebox.showinfo("Report", "Product movement - To be implemented")
    
    def stock_valuation(self):
        messagebox.showinfo("Report", "Stock valuation - To be implemented")
    
    def shop_settings(self):
        messagebox.showinfo("Settings", "Shop settings - To be implemented")
    
    def manage_suppliers(self):
        messagebox.showinfo("Suppliers", "Supplier management - To be implemented")
    
    def manage_expenses(self):
        messagebox.showinfo("Expenses", "Expense management - To be implemented")
    
    def user_management(self):
        messagebox.showinfo("Users", "User management - To be implemented")
    
    def backup_database(self):
        messagebox.showinfo("Backup", "Database backup - To be implemented")
    
    def activity_log(self):
        messagebox.showinfo("Log", "Activity log - To be implemented")
    
    def add_customer_quick(self):
        messagebox.showinfo("Add Customer", "Quick add customer - To be implemented")
    
    def show_user_guide(self):
        messagebox.showinfo("Help", "User guide - To be implemented")
    
    def show_shortcuts(self):
        shortcuts = """
        KEYBOARD SHORTCUTS:
        
        F1  - New Sale
        F2  - Focus Barcode Entry
        F3  - Search Product
        F4  - Clear Cart
        F5  - Complete Sale
        """
        messagebox.showinfo("Shortcuts", shortcuts)
    
    def show_about(self):
        about = """
        ShopMaster POS System
        Version 1.0
        
        Professional Point of Sale System
        for Ghanaian Retail Businesses
        
        © 2026 All Rights Reserved
        """
        messagebox.showinfo("About", about)
    
    def logout(self):
        """Logout current user"""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
            # Would return to login screen

# Login Window Class
class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("ShopMaster POS - Login")
        self.root.geometry("400x500")
        self.root.resizable(False, False)
        
        # Center window
        self.center_window()
        
        # Database path
        self.db_path = "pos_database.db"
        
        self.create_login_interface()
    
    def center_window(self):
        """Center window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_login_interface(self):
        """Create login screen"""
        
        # Header
        header = tk.Frame(self.root, bg="#2c3e50", height=100)
        header.pack(fill=tk.X)
        
        tk.Label(header, text="ShopMaster", font=("Arial", 24, "bold"),
                bg="#2c3e50", fg="white").pack(pady=10)
        tk.Label(header, text="Point of Sale System", font=("Arial", 12),
                bg="#2c3e50", fg="#ecf0f1").pack()
        
        # Login form
        form_frame = tk.Frame(self.root, bg="white")
        form_frame.pack(fill=tk.BOTH, expand=True, padx=40, pady=40)
        
        tk.Label(form_frame, text="Login to Continue", font=("Arial", 14, "bold"),
                bg="white").pack(pady=(0, 30))
        
        tk.Label(form_frame, text="Username:", font=("Arial", 10),
                bg="white").pack(anchor="w")
        self.username_entry = tk.Entry(form_frame, font=("Arial", 12))
        self.username_entry.pack(fill=tk.X, pady=(0, 15))
        self.username_entry.focus()
        
        tk.Label(form_frame, text="Password:", font=("Arial", 10),
                bg="white").pack(anchor="w")
        self.password_entry = tk.Entry(form_frame, font=("Arial", 12), show="●")
        self.password_entry.pack(fill=tk.X, pady=(0, 30))
        
        tk.Button(form_frame, text="LOGIN", font=("Arial", 12, "bold"),
                 bg="#27ae60", fg="white", command=self.login,
                 cursor="hand2", relief=tk.FLAT, pady=10).pack(fill=tk.X)
        
        # Bind enter key
        self.username_entry.bind('<Return>', lambda e: self.password_entry.focus())
        self.password_entry.bind('<Return>', lambda e: self.login())
        
        # Footer
        footer = tk.Frame(self.root, bg="#ecf0f1", height=50)
        footer.pack(fill=tk.X, side=tk.BOTTOM)
        
        tk.Label(footer, text="© 2026 ShopMaster POS. All Rights Reserved.",
                font=("Arial", 8), bg="#ecf0f1", fg="#7f8c8d").pack(pady=15)
    
    def login(self):
        """Handle login"""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        
        if not username or not password:
            messagebox.showwarning("Input Required", "Enter username and password")
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT user_id, username, full_name, role, is_active
                FROM users
                WHERE username = ? AND password = ?
            """, (username, password))
            
            user = cursor.fetchone()
            
            if user:
                user_id, username, full_name, role, is_active = user
                
                if is_active:
                    # Update last login
                    cursor.execute("""
                        UPDATE users 
                        SET last_login = ?
                        WHERE user_id = ?
                    """, (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), user_id))
                    
                    # Log activity
                    cursor.execute("""
                        INSERT INTO activity_log (user_id, activity_type, activity_description)
                        VALUES (?, 'Login', 'User logged in')
                    """, (user_id,))
                    
                    conn.commit()
                    conn.close()
                    
                    # Open main window
                    self.root.withdraw()
                    main_root = tk.Toplevel()
                    POSMainWindow(main_root, user_id, full_name, role)
                    main_root.protocol("WM_DELETE_WINDOW", self.root.quit)
                    
                else:
                    conn.close()
                    messagebox.showerror("Account Disabled", 
                                       "Your account has been disabled. Contact administrator.")
            else:
                conn.close()
                messagebox.showerror("Login Failed", 
                                   "Invalid username or password!")
                self.password_entry.delete(0, tk.END)
                
        except Exception as e:
            messagebox.showerror("Error", f"Login error: {e}")

# Main Application Entry
def main():
    """Main application entry point"""
    
    # Check if database exists
    if not os.path.exists("pos_database.db"):
        messagebox.showinfo("First Time Setup", 
                          "Database not found. Creating new database...")
        
        # Run database setup
        from database_setup import DatabaseSetup
        db = DatabaseSetup()
        if db.initialize_database():
            messagebox.showinfo("Setup Complete", 
                              "Database initialized successfully!\n\n"
                              "Default Login:\n"
                              "Username: admin\n"
                              "Password: admin123")
        else:
            messagebox.showerror("Setup Failed", "Failed to initialize database!")
            return
    
    # Start application
    root = tk.Tk()
    LoginWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()
