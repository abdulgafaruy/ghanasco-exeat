"""
SHOP MASTER POS - DATABASE SCHEMA
Complete database structure for POS system
"""

import sqlite3
from datetime import datetime
import os

class DatabaseSetup:
    def __init__(self, db_path="pos_database.db"):
        self.db_path = db_path
        self.conn = None
        
    def create_connection(self):
        """Create database connection"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            return self.conn
        except sqlite3.Error as e:
            print(f"Database connection error: {e}")
            return None
    
    def create_tables(self):
        """Create all database tables"""
        
        cursor = self.conn.cursor()
        
        # 1. USERS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('Admin', 'Manager', 'Cashier')),
                email TEXT,
                phone TEXT,
                is_active INTEGER DEFAULT 1,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP,
                last_login TEXT
            )
        ''')
        
        # 2. SHOP SETTINGS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS shop_settings (
                setting_id INTEGER PRIMARY KEY AUTOINCREMENT,
                shop_name TEXT NOT NULL,
                shop_address TEXT,
                shop_phone TEXT,
                shop_email TEXT,
                tin_number TEXT,
                currency TEXT DEFAULT 'GHS',
                tax_rate REAL DEFAULT 0.0,
                receipt_footer TEXT,
                logo_path TEXT,
                last_updated TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 3. PRODUCT CATEGORIES TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_name TEXT UNIQUE NOT NULL,
                description TEXT,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 4. SUPPLIERS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS suppliers (
                supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_name TEXT NOT NULL,
                contact_person TEXT,
                phone TEXT,
                email TEXT,
                address TEXT,
                is_active INTEGER DEFAULT 1,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 5. PRODUCTS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                barcode TEXT UNIQUE,
                product_name TEXT NOT NULL,
                category_id INTEGER,
                supplier_id INTEGER,
                description TEXT,
                unit_of_measure TEXT DEFAULT 'pcs',
                cost_price REAL NOT NULL,
                selling_price REAL NOT NULL,
                quantity_in_stock INTEGER DEFAULT 0,
                reorder_level INTEGER DEFAULT 5,
                expiry_date TEXT,
                is_active INTEGER DEFAULT 1,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP,
                last_updated TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (category_id) REFERENCES categories(category_id),
                FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
            )
        ''')
        
        # 6. CUSTOMERS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                phone TEXT,
                email TEXT,
                address TEXT,
                credit_limit REAL DEFAULT 0,
                loyalty_points INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 7. SALES TABLE (Main sales transactions)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales (
                sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
                receipt_number TEXT UNIQUE NOT NULL,
                customer_id INTEGER,
                user_id INTEGER NOT NULL,
                sale_date TEXT DEFAULT CURRENT_TIMESTAMP,
                subtotal REAL NOT NULL,
                discount_amount REAL DEFAULT 0,
                tax_amount REAL DEFAULT 0,
                total_amount REAL NOT NULL,
                payment_method TEXT NOT NULL CHECK(payment_method IN 
                    ('Cash', 'Mobile Money', 'Card', 'Credit', 'Bank Transfer')),
                amount_paid REAL NOT NULL,
                change_given REAL DEFAULT 0,
                status TEXT DEFAULT 'Completed' CHECK(status IN 
                    ('Completed', 'Pending', 'Cancelled', 'Returned')),
                notes TEXT,
                FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 8. SALES ITEMS TABLE (Individual items in each sale)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                discount REAL DEFAULT 0,
                total_price REAL NOT NULL,
                FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(product_id)
            )
        ''')
        
        # 9. PURCHASES TABLE (Stock purchases from suppliers)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS purchases (
                purchase_id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                purchase_date TEXT DEFAULT CURRENT_TIMESTAMP,
                total_amount REAL NOT NULL,
                payment_status TEXT DEFAULT 'Pending' CHECK(payment_status IN 
                    ('Paid', 'Pending', 'Partial')),
                amount_paid REAL DEFAULT 0,
                notes TEXT,
                FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 10. PURCHASE ITEMS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS purchase_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                purchase_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                unit_cost REAL NOT NULL,
                total_cost REAL NOT NULL,
                FOREIGN KEY (purchase_id) REFERENCES purchases(purchase_id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(product_id)
            )
        ''')
        
        # 11. EXPENSES TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS expenses (
                expense_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                expense_date TEXT DEFAULT CURRENT_TIMESTAMP,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL,
                payment_method TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 12. CASH DRAWER TABLE (Daily cash management)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cash_drawer (
                drawer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                opening_date TEXT DEFAULT CURRENT_TIMESTAMP,
                opening_balance REAL NOT NULL,
                closing_date TEXT,
                closing_balance REAL,
                expected_balance REAL,
                variance REAL,
                status TEXT DEFAULT 'Open' CHECK(status IN ('Open', 'Closed')),
                notes TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 13. STOCK ADJUSTMENTS TABLE
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_adjustments (
                adjustment_id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                adjustment_date TEXT DEFAULT CURRENT_TIMESTAMP,
                adjustment_type TEXT NOT NULL CHECK(adjustment_type IN 
                    ('Add', 'Remove', 'Damage', 'Expired', 'Transfer')),
                quantity INTEGER NOT NULL,
                reason TEXT,
                FOREIGN KEY (product_id) REFERENCES products(product_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 14. ACTIVITY LOG TABLE (User activity tracking)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS activity_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                activity_type TEXT NOT NULL,
                activity_description TEXT NOT NULL,
                activity_date TEXT DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # 15. CUSTOMER CREDIT TABLE (Track credit sales)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customer_credit (
                credit_id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                sale_id INTEGER,
                credit_date TEXT DEFAULT CURRENT_TIMESTAMP,
                amount REAL NOT NULL,
                amount_paid REAL DEFAULT 0,
                balance REAL NOT NULL,
                due_date TEXT,
                status TEXT DEFAULT 'Pending' CHECK(status IN 
                    ('Pending', 'Paid', 'Overdue')),
                FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
                FOREIGN KEY (sale_id) REFERENCES sales(sale_id)
            )
        ''')
        
        # Create indexes for better performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sales_user ON sales(user_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_products_name ON products(product_name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone)')
        
        self.conn.commit()
        print("✓ All database tables created successfully")
    
    def insert_default_data(self):
        """Insert default data for first-time setup"""
        
        cursor = self.conn.cursor()
        
        # Insert default admin user
        try:
            cursor.execute('''
                INSERT INTO users (username, password, full_name, role, email)
                VALUES (?, ?, ?, ?, ?)
            ''', ('admin', 'admin123', 'System Administrator', 'Admin', 
                  'admin@shopmaster.com'))
            print("✓ Default admin user created (Username: admin, Password: admin123)")
        except sqlite3.IntegrityError:
            print("! Admin user already exists")
        
        # Insert default shop settings
        try:
            cursor.execute('''
                INSERT INTO shop_settings 
                (shop_name, shop_address, shop_phone, currency, tax_rate)
                VALUES (?, ?, ?, ?, ?)
            ''', ('My Shop', 'Accra, Ghana', '0200000000', 'GHS', 0.0))
            print("✓ Default shop settings created")
        except sqlite3.IntegrityError:
            print("! Shop settings already exist")
        
        # Insert default categories
        default_categories = [
            'Food & Beverages', 'Electronics', 'Clothing', 
            'Household Items', 'Personal Care', 'Stationery', 'Other'
        ]
        
        for category in default_categories:
            try:
                cursor.execute('''
                    INSERT INTO categories (category_name)
                    VALUES (?)
                ''', (category,))
            except sqlite3.IntegrityError:
                pass  # Category already exists
        
        print("✓ Default categories created")
        
        # Insert sample customer (Walk-in customer)
        try:
            cursor.execute('''
                INSERT INTO customers (customer_name, phone)
                VALUES (?, ?)
            ''', ('Walk-in Customer', '0000000000'))
            print("✓ Default walk-in customer created")
        except sqlite3.IntegrityError:
            print("! Walk-in customer already exists")
        
        self.conn.commit()
    
    def initialize_database(self):
        """Main function to initialize complete database"""
        
        print("\n" + "="*60)
        print("SHOPMASTER POS - DATABASE INITIALIZATION")
        print("="*60 + "\n")
        
        # Create connection
        if self.create_connection():
            print("✓ Database connection established")
            
            # Create all tables
            self.create_tables()
            
            # Insert default data
            self.insert_default_data()
            
            print("\n" + "="*60)
            print("DATABASE INITIALIZATION COMPLETED SUCCESSFULLY")
            print("="*60)
            print("\nDEFAULT LOGIN CREDENTIALS:")
            print("  Username: admin")
            print("  Password: admin123")
            print("\n⚠ IMPORTANT: Change the default password immediately!")
            print("="*60 + "\n")
            
            self.conn.close()
            return True
        else:
            print("✗ Failed to initialize database")
            return False

# Run database setup
if __name__ == "__main__":
    db = DatabaseSetup()
    db.initialize_database()
