# SHOPMASTER POS - USER MANUAL
## Complete Guide for Daily Operations

---

## TABLE OF CONTENTS

1. Getting Started
2. Daily Opening Procedures
3. Processing Sales
4. Managing Products
5. Customer Management
6. Reports and Analysis
7. End of Day Procedures
8. Common Tasks
9. Troubleshooting
10. Best Practices

---

## 1. GETTING STARTED

### 1.1 Starting the System

**Method 1: Desktop Shortcut**
- Double-click **ShopMaster POS** icon on desktop
- System will start automatically

**Method 2: Command Line**
- Press Windows Key + R
- Type: cmd
- Type: cd C:\ShopMasterPOS
- Type: python main_pos.py
- Press Enter

### 1.2 Logging In

1. Enter your **Username**
2. Enter your **Password**
3. Click **LOGIN** button (or press Enter)

**Security Tips:**
- Never share your login credentials
- Always logout when leaving the computer
- Lock computer when stepping away (Windows Key + L)

### 1.3 Understanding the Interface

**Main Screen Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│  Menu Bar (File, Sales, Inventory, Reports, etc.)         │
├───────────────────────────┬─────────────────────────────────┤
│                           │                                 │
│   SALES TERMINAL          │    SUMMARY & PAYMENT            │
│                           │                                 │
│   [Barcode Entry]         │    Shop Name                    │
│                           │    Date & Time                  │
│   ┌───────────────────┐   │                                 │
│   │ Items in Cart     │   │    Customer: [Select]           │
│   │                   │   │                                 │
│   │  Product List     │   │    Items: 0                     │
│   │  Quantities       │   │    Subtotal: GHS 0.00          │
│   │  Prices           │   │    Discount: GHS 0.00          │
│   │                   │   │    Tax: GHS 0.00               │
│   └───────────────────┘   │    ═══════════════════         │
│                           │    TOTAL: GHS 0.00             │
│                           │                                 │
│                           │    Payment Method               │
│                           │    [COMPLETE SALE]             │
└───────────────────────────┴─────────────────────────────────┘
```

---

## 2. DAILY OPENING PROCEDURES

### 2.1 Start of Day Checklist

1. **Turn on computer and peripherals**
   - Computer/POS terminal
   - Receipt printer
   - Barcode scanner
   - Cash drawer

2. **Login to system**
   - Use your assigned username and password
   - Never use another person's login

3. **Open Cash Drawer**
   - Click: Admin → Cash Drawer → Open Drawer
   - Count opening cash carefully
   - Enter amount in system
   - Click Save

4. **System Checks**
   - Test receipt printer (print test receipt)
   - Test barcode scanner (scan a product)
   - Check internet connection (if applicable)
   - Verify date/time is correct

5. **Stock Verification**
   - Click: Inventory → Low Stock Alert
   - Note any products needing reorder
   - Report to manager

### 2.2 Opening Cash Drawer

**Step-by-Step:**

1. Count all cash in drawer:
   - GH¢ 200 notes: ___ x 200 = ___
   - GH¢ 100 notes: ___ x 100 = ___
   - GH¢ 50 notes: ___ x 50 = ___
   - GH¢ 20 notes: ___ x 20 = ___
   - GH¢ 10 notes: ___ x 10 = ___
   - GH¢ 5 notes: ___ x 5 = ___
   - GH¢ 2 notes: ___ x 2 = ___
   - GH¢ 1 coins: ___ x 1 = ___
   - 50p coins: ___ x 0.50 = ___
   
   **TOTAL: GH¢ _________**

2. Click: **Admin → Cash Drawer → Open Drawer**
3. Enter total amount
4. Click **Confirm**

**Important:** Two people should verify opening cash for accuracy

---

## 3. PROCESSING SALES

### 3.1 Simple Cash Sale (Most Common)

**Quick Steps:**

1. **Start new sale:** Press **F1** or click File → New Sale

2. **Add products:**
   - **Method A - Scan Barcode:**
     * Click in barcode field
     * Scan product with barcode scanner
     * Product automatically added
   
   - **Method B - Type Barcode:**
     * Click in barcode field
     * Type barcode number
     * Press Enter
   
   - **Method C - Search by Name:**
     * Press **F3** (Search Product)
     * Type product name
     * Select from results
     * Enter quantity
     * Click Add

3. **Review items in cart:**
   - Check product names
   - Verify quantities
   - Check prices

4. **Select customer:**
   - For walk-in: Leave as "Walk-in Customer"
   - For regular customer: Click dropdown and select

5. **Check payment method:**
   - Select: Cash (default)

6. **Complete sale:**
   - Click **COMPLETE SALE** button (or press **F5**)
   - Enter amount received
   - System calculates change
   - Click **COMPLETE PAYMENT**

7. **Print receipt:**
   - When asked, click **Yes**
   - Give receipt and change to customer

**Done! Next customer...**

### 3.2 Changing Quantities

**If customer wants 5 of an item:**

**Method 1 - Before adding:**
- When prompted, enter quantity: 5
- Click Add

**Method 2 - After adding:**
- Right-click on item in cart
- Select "Change Quantity"
- Enter new quantity: 5
- Click Update

### 3.3 Removing Items

**Customer changed mind:**

1. Right-click on item in cart
2. Select "Remove Item"
3. Confirm removal

### 3.4 Applying Discounts

**Special customer discount:**

**Option 1 - Item Discount:**
1. Right-click on item
2. Select "Apply Discount"
3. Choose:
   - Fixed Amount (GH¢): Enter amount (e.g., 5)
   - Percentage (%): Enter percentage (e.g., 10)
4. Click Apply

**Option 2 - Total Discount:**
1. Before completing sale
2. Click "Apply Total Discount"
3. Enter discount amount or percentage
4. Applies to entire sale

### 3.5 Mobile Money Payment

**Process:**

1. Add all items to cart
2. Select payment method: **Mobile Money**
3. Click **COMPLETE SALE**
4. Tell customer total amount
5. Customer sends mobile money
6. Verify payment received on phone
7. Enter customer phone number in system
8. Click **COMPLETE PAYMENT**
9. Print receipt

### 3.6 Card Payment

1. Add all items to cart
2. Select payment method: **Card**
3. Click **COMPLETE SALE**
4. Process card payment on POS machine
5. Wait for approval
6. Enter approval code in system
7. Click **COMPLETE PAYMENT**
8. Print receipt (customer and merchant copy)

### 3.7 Credit Sale (Trusted Customers)

**Important:** Only for approved customers with credit limit!

1. Add all items to cart
2. Select customer from dropdown
3. Verify customer has available credit
4. Select payment method: **Credit**
5. Click **COMPLETE SALE**
6. Customer signs receipt
7. File signed receipt securely

**Note:** Credit sales are tracked automatically in customer account

### 3.8 Split Payment

**Example: Customer pays part cash, part mobile money**

1. Process sale normally
2. When payment dialog appears:
   - Enter cash amount received
   - Note remaining balance
3. Click "Add Payment Method"
4. Select second method
5. Enter second amount
6. Complete transaction

### 3.9 Sales Return/Refund

**Customer wants to return an item:**

**Requirements:**
- Original receipt
- Items in good condition
- Within return period
- Manager approval

**Process:**

1. Click: **Sales → Sales Return**
2. Enter or scan receipt number
3. Sale details will load
4. Select items being returned
5. Enter reason for return
6. Get manager approval code
7. Select refund method:
   - Cash refund
   - Store credit
   - Exchange
8. Click **Process Return**
9. Give customer refund and return receipt

---

## 4. MANAGING PRODUCTS

### 4.1 Adding New Product

**Step-by-Step:**

1. Click: **Inventory → Products**
2. Click: **Add New Product** button
3. Fill in details:

   **Basic Information:**
   - Product Name: Enter full name
   - Barcode: Scan or type barcode
   - Category: Select from dropdown
   - Description: Brief description (optional)

   **Pricing:**
   - Cost Price: What you paid
   - Selling Price: What you charge
   - (System calculates markup automatically)

   **Stock:**
   - Quantity in Stock: Initial quantity
   - Unit of Measure: pcs, kg, liters, etc.
   - Reorder Level: Minimum before alert

   **Supplier (if applicable):**
   - Select supplier from dropdown

   **Other:**
   - Expiry Date: For perishable items
   - Is Active: Check to enable sales

4. Click **Save Product**

**Tips:**
- Use clear, descriptive product names
- Always enter accurate cost prices for profit tracking
- Set realistic reorder levels
- For products without barcodes, create custom codes

### 4.2 Editing Product Information

1. Click: **Inventory → Products**
2. Find product (use search box)
3. Click on product to select
4. Click **Edit** button
5. Make changes
6. Click **Update Product**

**Common Edits:**
- Price changes
- Stock quantity corrections
- Supplier changes
- Category reassignment

### 4.3 Adjusting Stock

**For damaged, expired, or missing items:**

1. Click: **Inventory → Stock Adjustment**
2. Click: **New Adjustment**
3. Search and select product
4. Select adjustment type:
   - **Add:** Receiving new stock
   - **Remove:** Stock sold elsewhere
   - **Damage:** Damaged items
   - **Expired:** Past expiry date
   - **Transfer:** Moving to another location
5. Enter quantity
6. Enter reason (required)
7. Click **Save Adjustment**

**Important:** All stock adjustments are logged and auditable

### 4.4 Checking Stock Levels

**Quick Stock Check:**

1. Click: **Inventory → Products**
2. Use search box to find product
3. View "Stock" column for current quantity

**Low Stock Alert:**

1. Click: **Inventory → Low Stock Alert**
2. View all products below reorder level
3. Print list for ordering
4. Contact suppliers

**Stock Valuation:**

1. Click: **Reports → Stock Valuation**
2. View total inventory value
3. View by category
4. Export to Excel for analysis

---

## 5. CUSTOMER MANAGEMENT

### 5.1 Registering New Customer

**Why register customers:**
- Track purchase history
- Offer loyalty rewards
- Enable credit sales
- Send promotions

**Process:**

1. Click: **Customers → Manage Customers**
2. Click: **Add New Customer**
3. Fill in information:
   - Full Name (required)
   - Phone Number (required)
   - Email (optional)
   - Address (optional)
   - Credit Limit (if applicable)
4. Click **Save Customer**

**Quick Add During Sale:**
- Click **+** button next to customer dropdown
- Enter name and phone
- Click Save
- Customer available immediately

### 5.2 Viewing Customer History

1. Click: **Customers → Manage Customers**
2. Find and select customer
3. Click **View History**
4. See:
   - All purchases
   - Total spent
   - Last visit
   - Loyalty points
   - Credit balance

### 5.3 Customer Statement

**For credit customers:**

1. Click: **Customers → Customer Statement**
2. Select customer
3. Select date range
4. Click **Generate Statement**
5. View:
   - Opening balance
   - All sales on credit
   - Payments made
   - Current balance
6. Print or email to customer

### 5.4 Loyalty Points

**Earning Points:**
- Customers earn 1 point per GH¢ spent
- Points automatically added to account

**Redeeming Points:**
1. During sale, select customer
2. System shows available points
3. Click "Redeem Points"
4. Enter points to redeem
5. Value deducted from total

**Managing Points:**
- View points in customer details
- Adjust points manually if needed (Admin only)
- Set points expiry (in settings)

---

## 6. REPORTS AND ANALYSIS

### 6.1 Daily Sales Report

**End of every day:**

1. Click: **Reports → Daily Sales Report**
2. Select date (default is today)
3. Click **Generate**
4. Report shows:
   - Total sales value
   - Number of transactions
   - Cash sales
   - Card sales
   - Mobile money
   - Credit sales
   - Total items sold
   - Best-selling products

**Actions:**
- Print for records
- Export to Excel
- Email to manager

### 6.2 Monthly Sales Report

**Monthly business review:**

1. Click: **Reports → Monthly Sales Report**
2. Select month and year
3. Click **Generate**
4. View:
   - Sales by day
   - Sales trends
   - Top products
   - Top customers
   - Payment method breakdown
   - Comparison to previous month

### 6.3 Profit Analysis

**Know your margins:**

1. Click: **Reports → Profit Analysis**
2. Select date range
3. Click **Generate**
4. See:
   - Total revenue
   - Total cost
   - Gross profit
   - Profit margin %
   - Profit by category
   - Profit by product

**Use this to:**
- Identify most profitable products
- Review pricing strategy
- Focus on high-margin items

### 6.4 Product Movement Report

**Track what sells:**

1. Click: **Reports → Product Movement**
2. Select date range
3. Optional: Select category
4. Click **Generate**
5. View:
   - Products sold (quantity)
   - Revenue per product
   - Fast-moving items
   - Slow-moving items
   - Dead stock

**Action Items:**
- Reorder fast movers
- Discount slow movers
- Remove dead stock

### 6.5 Cashier Performance

**For managers - staff evaluation:**

1. Click: **Reports → Cashier Performance**
2. Select date range
3. Select cashier (or All)
4. Click **Generate**
5. See:
   - Number of sales
   - Total value
   - Average sale value
   - Returns processed
   - Discounts given
   - Time per transaction

---

## 7. END OF DAY PROCEDURES

### 7.1 Closing Cash Drawer

**IMPORTANT: Do this EVERY day before leaving!**

**Step-by-Step:**

1. **Count closing cash:**
   - Count all denominations
   - Use same format as opening count
   - Double-check accuracy

2. **Close in system:**
   - Click: **Admin → Cash Drawer → Close Drawer**
   - Enter closing amount
   - System shows expected amount
   - Enter any variance
   - Enter reason if variance exists
   - Click **Close Drawer**

3. **Handle variance:**
   - **Overage:** Cash more than expected
   - **Shortage:** Cash less than expected
   - Report significant variances to manager
   - Investigate and document reason

4. **Secure cash:**
   - Place in safe or secure location
   - Prepare bank deposit
   - Keep float for next day

### 7.2 Daily Reports

**Generate these reports:**

1. **Daily Sales Summary**
   - Total sales for the day
   - Print two copies (one for records, one for manager)

2. **Stock Movement**
   - What was sold today
   - Review low stock items

3. **Cash Reconciliation**
   - Opening balance
   - Total sales
   - Expected closing
   - Actual closing
   - Variance

### 7.3 End of Day Checklist

Complete this checklist EVERY day:

□ Count and close cash drawer
□ Print daily sales report
□ Print cash reconciliation
□ Backup database (if configured)
□ Check for low stock alerts
□ Note any issues or concerns
□ Clean workstation
□ Turn off receipt printer
□ Lock cash drawer
□ Logout from system
□ Shutdown computer properly

---

## 8. COMMON TASKS

### 8.1 Changing Your Password

**Do this regularly for security:**

1. Click: **File → Change Password**
2. Enter current password
3. Enter new password
4. Confirm new password
5. Click **Update Password**

**Password Requirements:**
- At least 8 characters
- Mix of uppercase and lowercase
- Include numbers
- Don't use personal info

### 8.2 Searching for Products

**Fast Product Search:**

1. Press **F3** anywhere
2. Type product name (partial name works)
3. Results appear as you type
4. Click on product to select
5. Add to sale or view details

### 8.3 Voiding a Sale

**Made a mistake?**

**Before completing:**
- Press **F4** to clear cart
- Start fresh

**After completing:**
- Use Sales Return function
- Requires manager approval
- Must have receipt

### 8.4 Reprinting Receipts

**Customer lost receipt:**

1. Click: **Sales → View Sales History**
2. Find the sale (search by date, receipt number, or customer)
3. Select the sale
4. Click **Reprint Receipt**
5. Mark as "DUPLICATE" or "COPY"

**Note:** All reprints are logged

### 8.5 Handling Price Checks

**Customer asks for price:**

1. Press **F3** (Search)
2. Type product name or scan barcode
3. Price displayed
4. Press Escape to close
5. Continue with sale

---

## 9. TROUBLESHOOTING

### 9.1 Barcode Scanner Not Working

**Symptoms:** Scanner beeps but doesn't enter barcode

**Solutions:**
1. Check USB connection
2. Unplug and replug scanner
3. Test in notepad - should type numbers
4. Check scanner mode (should be keyboard mode)
5. Try manual barcode entry
6. Contact IT support if persists

### 9.2 Receipt Printer Not Printing

**Quick Checks:**

1. **Is printer ON?** Check power light
2. **Paper loaded?** Install new roll
3. **Paper jam?** Open and check
4. **Cable connected?** Check USB cable
5. **Right printer selected?** Check in settings
6. **Driver installed?** Reinstall if needed

**Test:**
- Print test page from Windows
- If Windows print works, check POS settings
- If Windows print fails, reinstall printer driver

### 9.3 System Running Slow

**Common Causes:**

1. **Too many old records:** Archive old data
2. **Low disk space:** Clean up disk
3. **Multiple programs open:** Close unnecessary programs
4. **Computer needs restart:** Restart daily
5. **Database needs optimization:** Contact administrator

### 9.4 Can't Login

**Possible Issues:**

1. **Wrong password:**
   - Try again carefully
   - Check CAPS LOCK
   - Use "Forgot Password" if available

2. **Account disabled:**
   - Contact administrator
   - May be security measure

3. **Database connection:**
   - Check if database file exists
   - Restart system
   - Contact IT support

### 9.5 Product Not Found

**When scanning barcode:**

1. Try scanning again
2. Check barcode is clean
3. Type barcode manually
4. Search by product name (F3)
5. Check product is marked "Active"
6. Add product if new

### 9.6 Calculation Errors

**Price seems wrong:**

1. Check product price in system
2. Check if discount applied
3. Check tax rate in settings
4. Verify quantity
5. Recalculate manually
6. Report to manager if error confirmed

---

## 10. BEST PRACTICES

### 10.1 Speed and Efficiency

**Serve customers faster:**

1. **Learn keyboard shortcuts:**
   - F1: New sale
   - F2: Focus barcode field
   - F3: Search product
   - F4: Clear cart
   - F5: Complete sale

2. **Keep workspace organized:**
   - Scanner within reach
   - Products arranged logically
   - Cash drawer organized by denomination

3. **Prepare in advance:**
   - Know popular products
   - Have bags ready
   - Keep change available

4. **Use barcodes whenever possible:**
   - Much faster than manual search
   - Reduces errors

5. **Master the system:**
   - Practice during quiet times
   - Learn product locations
   - Know common prices

### 10.2 Accuracy

**Avoid mistakes:**

1. **Double-check before completing:**
   - Verify all items
   - Check quantities
   - Confirm prices
   - Verify total

2. **Count change carefully:**
   - Count back to customer
   - Use calculator if needed
   - Keep denominations organized

3. **Handle returns properly:**
   - Check receipt
   - Inspect items
   - Get authorization
   - Document reason

4. **Stock management:**
   - Report damaged items immediately
   - Update stock adjustments promptly
   - Note discrepancies

### 10.3 Customer Service

**Provide excellent service:**

1. **Greet every customer:**
   - Smile and make eye contact
   - Be polite and friendly
   - Use customer names when known

2. **Be efficient:**
   - Process sales quickly
   - Don't make customers wait
   - Apologize for delays

3. **Handle complaints well:**
   - Listen carefully
   - Stay calm and professional
   - Call manager if needed
   - Resolve issues fairly

4. **Know your products:**
   - Learn what you sell
   - Help customers find items
   - Suggest alternatives

5. **Thank customers:**
   - Always say thank you
   - Invite them back
   - Provide receipt

### 10.4 Security

**Protect the business:**

1. **Never share passwords**
2. **Logout when leaving**
3. **Lock computer (Windows Key + L)**
4. **Watch for shoplifting**
5. **Verify large bills**
6. **Count change carefully**
7. **Report suspicious activity**
8. **Secure cash drawer**
9. **Don't process fake returns**
10. **Follow all procedures**

### 10.5 Professionalism

**Be a great employee:**

1. **Arrive on time**
2. **Dress appropriately**
3. **Stay focused**
4. **Follow company policies**
5. **Be honest**
6. **Help teammates**
7. **Keep learning**
8. **Take pride in your work**
9. **Communicate clearly**
10. **Maintain positive attitude**

---

## QUICK REFERENCE CARD

**KEYBOARD SHORTCUTS:**
- F1: New Sale
- F2: Focus Barcode Entry
- F3: Search Product
- F4: Clear Cart
- F5: Complete Sale
- Windows Key + L: Lock Computer

**DAILY ROUTINE:**
1. Login → Open Cash Drawer → Check System
2. Process Sales All Day
3. Close Cash Drawer → Print Reports → Logout

**SALE PROCESS:**
1. Scan/Search Products
2. Review Cart
3. Select Payment
4. Complete Sale
5. Print Receipt

**NEED HELP?**
- Press F1 for help
- Check this manual
- Ask supervisor
- Call IT support

---

## APPENDIX: TERMINOLOGY

**Common Terms:**

- **SKU:** Stock Keeping Unit - unique product code
- **Barcode:** Machine-readable product code
- **Receipt Number:** Unique sale identifier
- **Float:** Starting cash in drawer
- **Overage:** Extra cash in drawer
- **Shortage:** Missing cash from drawer
- **Void:** Cancel a sale
- **Refund:** Return customer money
- **Credit Limit:** Maximum credit allowed
- **Reorder Level:** Minimum stock before ordering
- **Markup:** Difference between cost and selling price
- **Margin:** Profit as percentage of selling price

---

**Document Version:** 1.0  
**Last Updated:** February 2026  
**For:** ShopMaster POS System

**KEEP THIS MANUAL HANDY AT ALL TIMES!**
