# SHOPMASTER POS - INSTALLATION GUIDE
## Step-by-Step Installation for Windows

---

## BEFORE YOU START

### WHAT YOU NEED:
✓ Windows computer (Windows 7/8/10/11)
✓ Administrator access
✓ Internet connection (for initial setup)
✓ 30 minutes of time
✓ This installation guide

### WHAT YOU WILL INSTALL:
1. Python programming language
2. Required Python packages
3. ShopMaster POS System
4. Database setup

---

## STEP 1: INSTALL PYTHON

### 1.1 Download Python

1. Open your web browser
2. Go to: **https://www.python.org/downloads/**
3. Click the big yellow button that says **"Download Python"**
4. Wait for download to complete (about 25MB)
5. Find the downloaded file (usually in Downloads folder)
   - File name: **python-3.x.x.exe**

### 1.2 Install Python

**IMPORTANT: Follow these steps EXACTLY**

1. **Double-click** the downloaded Python file
2. **CHECK the box** that says **"Add Python to PATH"** 
   ⚠ THIS IS VERY IMPORTANT - Don't skip this!
3. Click **"Install Now"**
4. Wait for installation (2-3 minutes)
5. When you see "Setup was successful", click **"Close"**

### 1.3 Verify Python Installation

1. Press **Windows Key + R**
2. Type: **cmd**
3. Press **Enter**
4. In the black window that opens, type: **python --version**
5. Press **Enter**
6. You should see: **Python 3.x.x**

✓ If you see the version, Python is installed correctly!
✗ If you see "python is not recognized", Python PATH not set correctly

---

## STEP 2: INSTALL REQUIRED PACKAGES

### 2.1 Open Command Prompt

1. Press **Windows Key + R**
2. Type: **cmd**
3. Press **Enter**

### 2.2 Install Packages One by One

Copy and paste each command below into Command Prompt and press Enter:

```
pip install pillow
```
Wait for completion, then:

```
pip install reportlab
```
Wait for completion, then:

```
pip install openpyxl
```
Wait for completion, then:

```
pip install tkcalendar
```

### What These Packages Do:
- **pillow**: For image handling (logos, receipts)
- **reportlab**: For PDF generation (reports)
- **openpyxl**: For Excel export (sales data)
- **tkcalendar**: For date selection in the system

---

## STEP 3: SETUP SHOPMASTER POS

### 3.1 Create Installation Folder

1. Open **File Explorer** (Windows Key + E)
2. Go to **C:\\ drive**
3. Create a new folder called: **ShopMasterPOS**
4. Open the **ShopMasterPOS** folder

### 3.2 Copy System Files

Copy all these files into **C:\\ShopMasterPOS**:

Required Files:
- main_pos.py (Main application)
- database_setup.py (Database creator)
- SYSTEM_OVERVIEW.md (Documentation)
- pos_database.db (Will be created automatically)

### 3.3 Initialize Database

1. Open Command Prompt (Windows Key + R, type cmd)
2. Type: **cd C:\\ShopMasterPOS**
3. Press Enter
4. Type: **python database_setup.py**
5. Press Enter

You should see:
```
====================================
SHOPMASTER POS - DATABASE INITIALIZATION
====================================

✓ Database connection established
✓ All database tables created successfully
✓ Default admin user created
✓ Default shop settings created
✓ Default categories created
✓ Default walk-in customer created

====================================
DATABASE INITIALIZATION COMPLETED SUCCESSFULLY
====================================

DEFAULT LOGIN CREDENTIALS:
  Username: admin
  Password: admin123

⚠ IMPORTANT: Change the default password immediately!
====================================
```

✓ Database setup complete!

---

## STEP 4: FIRST TIME RUN

### 4.1 Start the System

1. Open Command Prompt
2. Type: **cd C:\\ShopMasterPOS**
3. Press Enter
4. Type: **python main_pos.py**
5. Press Enter

### 4.2 Login

The login screen will appear:

```
Username: admin
Password: admin123
```

Click **LOGIN**

---

## STEP 5: INITIAL CONFIGURATION

### 5.1 Change Admin Password (MANDATORY)

1. After login, click menu: **Admin → User Management**
2. Select admin user
3. Click **Change Password**
4. Enter new strong password
5. Click **Save**

**Strong Password Tips:**
- At least 8 characters
- Mix of uppercase and lowercase
- Include numbers
- Include special characters (@, #, $, etc.)

### 5.2 Configure Shop Settings

1. Click menu: **Admin → Shop Settings**
2. Fill in your shop details:
   - Shop Name
   - Address
   - Phone Number
   - Email
   - TIN Number (for tax purposes)
   - Currency (GHS for Ghana)
   - Tax Rate (VAT percentage)
3. Upload your shop logo (optional)
4. Click **Save**

### 5.3 Add Product Categories

1. Click menu: **Inventory → Categories**
2. Review default categories
3. Add more categories specific to your business
4. Click **Save**

### 5.4 Add Products

1. Click menu: **Inventory → Products**
2. Click **Add New Product**
3. Fill in product details:
   - Product Name
   - Barcode (scan or type)
   - Category
   - Cost Price
   - Selling Price
   - Initial Stock Quantity
   - Reorder Level
4. Click **Save**
5. Repeat for all your products

---

## STEP 6: CREATE DESKTOP SHORTCUT (OPTIONAL)

### 6.1 Create Batch File

1. Open Notepad
2. Type:
```
@echo off
cd C:\ShopMasterPOS
python main_pos.py
pause
```
3. Click **File → Save As**
4. Save as: **RunPOS.bat** (make sure to select "All Files" type)
5. Save in **C:\\ShopMasterPOS**

### 6.2 Create Desktop Shortcut

1. Right-click on **RunPOS.bat**
2. Click **Send to → Desktop (create shortcut)**
3. Right-click the desktop shortcut
4. Click **Properties**
5. Change **Run:** from "Normal window" to "Minimized"
6. Click **OK**

Now you can double-click the shortcut to start the system!

---

## TROUBLESHOOTING

### Problem: "Python is not recognized"
**Solution:**
1. Uninstall Python
2. Reinstall and CHECK "Add Python to PATH"
3. Restart computer

### Problem: "pip is not recognized"
**Solution:**
Same as Python problem - reinstall with PATH checked

### Problem: "Module not found" error
**Solution:**
Reinstall the missing package:
```
pip install [package-name] --upgrade
```

### Problem: Database won't create
**Solution:**
1. Make sure you have write permission in folder
2. Run Command Prompt as Administrator
3. Run database_setup.py again

### Problem: Window appears then closes immediately
**Solution:**
1. There's likely a Python error
2. Run from Command Prompt to see the error
3. Check all required packages are installed

### Problem: Can't see printed receipts
**Solution:**
1. Check printer is connected and ON
2. Check printer drivers installed
3. Set default printer in Windows
4. Configure printer in Shop Settings

---

## NETWORK INSTALLATION (Multiple Computers)

If you want to use the system on multiple computers:

### Server Computer Setup:
1. Install everything as above
2. Install MySQL Server
3. Configure database connection
4. Share database access

### Client Computer Setup:
1. Install Python and packages
2. Copy main_pos.py
3. Configure to connect to server database
4. Test connection

**Note:** Network setup requires advanced technical knowledge. Consider hiring an IT professional.

---

## BACKUP SETUP

### Automatic Backup (Recommended):

1. Click **Admin → Backup Database**
2. Choose backup location (external drive recommended)
3. Enable **"Auto Daily Backup"**
4. Set backup time (e.g., 11:00 PM)
5. Click **Save**

### Manual Backup:

1. Copy **pos_database.db** file from **C:\\ShopMasterPOS**
2. Paste to safe location:
   - External USB drive
   - Cloud storage (Google Drive, OneDrive)
   - Another computer

**Do this EVERY DAY at closing!**

---

## IMPORTANT SECURITY REMINDERS

1. ✓ Change default admin password immediately
2. ✓ Create individual user accounts for each staff member
3. ✓ Don't share passwords
4. ✓ Lock computer when leaving desk
5. ✓ Backup database daily
6. ✓ Keep Windows updated
7. ✓ Install antivirus software
8. ✓ Use UPS (power backup) to prevent data loss

---

## GETTING HELP

### Built-in Help:
- Press **F1** in any screen for context help
- Click **Help → User Guide** for detailed instructions
- Click **Help → Keyboard Shortcuts** for quick reference

### Documentation:
- Read **SYSTEM_OVERVIEW.md** for complete features
- Check troubleshooting section first

### Technical Support:
- Keep system error messages
- Note what you were doing when error occurred
- Have system version information ready

---

## NEXT STEPS AFTER INSTALLATION

### Day 1:
- Change admin password ✓
- Configure shop settings ✓
- Add product categories ✓
- Add 5-10 sample products ✓
- Practice making test sales ✓

### Day 2:
- Add remaining products
- Train staff on basic operations
- Test barcode scanner (if using)
- Test receipt printer (if using)
- Setup backup system

### Day 3:
- Create user accounts for staff
- Assign appropriate roles
- Monitor system performance
- Review daily reports
- Fine-tune settings

### Week 1:
- Input all inventory
- Register regular customers
- Setup suppliers
- Review sales reports
- Adjust based on workflow

---

## SYSTEM REQUIREMENTS CHECKLIST

Before going live, verify:

□ Python installed correctly
□ All packages installed
□ Database initialized
□ Admin password changed
□ Shop settings configured
□ Products added
□ Categories setup
□ Users created
□ Backup system configured
□ Staff trained on basic operations
□ Receipt printer tested (if using)
□ Barcode scanner tested (if using)
□ Sample transactions completed successfully

---

## MAINTENANCE SCHEDULE

### Daily:
- Backup database
- Review sales reports
- Check low stock alerts

### Weekly:
- Check disk space
- Review user activity logs
- Clean temporary files
- Update product prices if needed

### Monthly:
- Full system backup to external drive
- Generate monthly reports
- Review and archive old data
- Check for system updates

### Quarterly:
- Deep clean database
- Performance optimization
- Security audit
- User training refresh

---

## LEGAL COMPLIANCE

### Ghana Revenue Authority (GRA) Requirements:
- Keep all sales receipts for 6 years minimum
- VAT registered businesses must show VAT on receipts
- TIN number must appear on receipts
- Regular backups for audit purposes

### Data Protection:
- Protect customer personal information
- Don't share customer data without consent
- Secure all computers with passwords
- Follow Ghana Data Protection Act

---

## CONGRATULATIONS!

You have successfully installed ShopMaster POS!

**Remember:**
- Practice with test data before going live
- Train all staff thoroughly
- Backup regularly
- Keep this guide handy

**Ready to start selling? Let's go!**

---

**Document Version:** 1.0  
**Last Updated:** February 2026  
**For:** ShopMaster POS Version 1.0
